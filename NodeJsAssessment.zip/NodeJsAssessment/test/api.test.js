var supertest = require("supertest");
var should = require("should");

// This agent refers to PORT where program is runninng.

var server = supertest.agent("http://localhost:3000");

// UNIT test begin

describe("PARSE POST API TEST",function(){

  it("v1 parse API - /api/v1/parse",function(done){

    //calling ADD api
    server
    .post('/api/v1/parse')
    .send({"data": "JOHN0000MICHAEL0009994567"})
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      let response = '{"statusCode":200,"data":{"firstName":"JOHN0000","lastName":"MICHAEL000","clientId":"9994567"}}';
      res.status.should.equal(200);
      res.body.statusCode.should.equal(200);
      res.body.should.eql(JSON.parse(response));
      done();
    });
  });

  it("v2 parse API - /api/v2/parse",function(done){

    //calling ADD api
    server
    .post('/api/v2/parse')
    .send({"data": "JOHN0000MICHAEL0009994567"})
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      let response = '{"statusCode":200,"data":{"firstName":"JOHN","lastName":"MICHAEL","clientId":"999-4567"}}';
      res.status.should.equal(200);
      res.body.statusCode.should.equal(200);
      res.body.should.eql(JSON.parse(response));
      done();
    });
  });

});