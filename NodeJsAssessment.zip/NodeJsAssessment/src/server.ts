// lib/app.ts
import express = require('express');
import bodyParser = require('body-parser')

import {config} from 'node-config-ts'
import { Version2Parser } from "./version2Parser";
import { Version1Parser } from './version1Parser';

// Create a new express application instance
const app: express.Application = express();
app.use(bodyParser.json());

app.get('/health-check', function(req, res) {
  res.send("Server is up and running on port: " + config.port);
});


app.post('/api/:version/parse', function (req, res) {

    let iParser : IParser | undefined;
    if(req.params.version == 'v1'){
      iParser = new Version1Parser();
    }
    else if(req.params.version == 'v2') {
      iParser = new Version2Parser();
    }
  
    if(iParser != undefined)
     res.send(iParser.parse(req.body.data));
    else
      res.send(req.params.version + ' api is not supported.');
});

app.listen(config.port, function () {
  console.log('Server started listening on port: ' + config.port);
});