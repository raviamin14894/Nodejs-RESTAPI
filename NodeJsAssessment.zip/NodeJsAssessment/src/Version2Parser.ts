export class Version2Parser implements IParser {
    
    parse(inputData: String): IResponse {
        let v2response : IResponse = {
            statusCode : 200,
            data : {
                firstName : inputData.substring(0, 4),
                lastName : inputData.substring(8, 15),
                clientId : inputData.substring(18, 21) + "-" + inputData.substring(21, inputData.length)
            }
        }
        return v2response;
    }
}