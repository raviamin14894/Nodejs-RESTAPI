interface IResponse {
    statusCode : number
    data : {
        firstName : String
        lastName : String
        clientId : String
    }
}