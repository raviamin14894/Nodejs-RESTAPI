interface IParser {
    parse(inputData: String) : IResponse;
}