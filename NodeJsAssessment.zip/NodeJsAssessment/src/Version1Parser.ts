export class Version1Parser implements IParser {
    
    parse(inputData: String): IResponse {
        let v1response : IResponse = {
            statusCode : 200,
            data : {
                firstName : inputData.substring(0, 8),
                lastName : inputData.substring(8, 18),
                clientId : inputData.substring(18, inputData.length)
            }
        }
        return v1response;
    }
}